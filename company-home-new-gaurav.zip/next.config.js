module.exports = {
  // ...other config...
  images: {
    domains: [
      "images.unsplash.com",
      // add other domains if needed
    ],
  },
};