// "use client";
// import React from "react";
// import homeData from "@/data/homeData.json";

// const DiscussProject = () => {
//     const { discussProject } = homeData;

//     return (
//         <section className="relative w-full h-[500px] md:h-[550px] overflow-hidden rounded-2xl shadow-lg">
//             {/* Google Map Background */}
//             <iframe
//                 src={discussProject.mapUrl}
//                 width="100%"
//                 height="100%"
//                 style={{ border: 0 }}
//                 allowFullScreen=""
//                 loading="lazy"
//                 referrerPolicy="no-referrer-when-downgrade"
//                 className="absolute inset-0 w-full h-full"
//             ></iframe>

//             {/* Overlay Gradient (non-interactive) */}
//             <div className="absolute inset-0 bg-gradient-to-r from-white/90 via-white/70 to-transparent pointer-events-none"></div>

//             {/* Text Content (interactive again) */}
//             <div className="absolute top-1/2 left-6 md:left-16 -translate-y-1/2 z-10 max-w-lg pointer-events-auto">
//                 <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
//                     {discussProject.title}
//                 </h2>
//                 <p className="text-gray-700 mb-6 leading-relaxed">
//                     {discussProject.description}
//                 </p>
//                 <button className="bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-6 rounded-full transition duration-300">
//                     {discussProject.buttonText}
//                 </button>
//             </div>
//         </section>
//     );
// };

// export default DiscussProject;





"use client";
import React from "react";
import Link from "next/link";
import homeData from "@/data/homeData.json";

const DiscussProject = () => {
    const { discussProject } = homeData;

    return (
        <section className="w-full overflow-hidden rounded-2xl shadow-lg">
            {/* Google Map Background */}
            <div className="relative w-full h-[400px] md:h-[500px]">
                <iframe
                    src={discussProject.mapUrl}
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen=""
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    className="absolute inset-0 w-full h-full"
                ></iframe>

                {/* Text Box (on top for md+, hidden on mobile) */}
                <div className="hidden md:block absolute top-1/2 left-6 md:left-16 -translate-y-1/2 z-10 max-w-lg bg-white/10 backdrop-blur-sm p-8 rounded-xl shadow-lg">
                    <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4 leading-tight">
                        {discussProject.title}
                    </h2>
                    <p className="text-gray-700 mb-6 leading-relaxed">
                        {discussProject.description}
                    </p>
                    <Link
                        href={discussProject.buttonUrl}
                        className="inline-block bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-6 rounded-full transition duration-300"
                    >
                        {discussProject.buttonText}
                    </Link>
                </div>
            </div>

            {/* Text Box (below map for mobile) */}
            <div className="md:hidden bg-white p-6 rounded-b-2xl shadow-md">
                <h2 className="text-2xl font-bold text-gray-900 mb-3">
                    {discussProject.title}
                </h2>
                <p className="text-gray-700 mb-5 leading-relaxed">
                    {discussProject.description}
                </p>
                <Link
                    href={discussProject.buttonUrl}
                    className="block text-center bg-red-500 hover:bg-red-600 text-white font-semibold py-3 px-6 rounded-full transition duration-300"
                >
                    {discussProject.buttonText}
                </Link>
            </div>
        </section>
    );
};

export default DiscussProject;
